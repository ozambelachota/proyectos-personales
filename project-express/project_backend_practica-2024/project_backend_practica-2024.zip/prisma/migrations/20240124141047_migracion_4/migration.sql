-- AlterTable
ALTER TABLE `chofer` MODIFY `fingreso` DATETIME(3) NOT NULL;
