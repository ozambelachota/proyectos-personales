-- DropIndex
DROP INDEX `Bus_placa_key` ON `bus`;
