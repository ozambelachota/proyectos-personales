-- AlterTable
ALTER TABLE `chofer` MODIFY `fingreso` DATE NOT NULL;
