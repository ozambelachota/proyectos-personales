-- DropIndex
DROP INDEX `Chofer_dni_key` ON `chofer`;
