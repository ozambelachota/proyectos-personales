const dbBus = require("../db/db.config");

const itinerarioSchema = dbBus.itinerario
module.exports = itinerarioSchema;
