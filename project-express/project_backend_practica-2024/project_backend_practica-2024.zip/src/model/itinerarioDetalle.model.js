const dbBus = require("../db/db.config");

const itinerarioDetalleSchema = dbBus.detalleItinerario

module.exports = itinerarioDetalleSchema;
