const dbBus = require("../db/db.config");

const usuarioSchema = dbBus.usuario

module.exports = usuarioSchema;
