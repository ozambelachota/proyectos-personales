const dbBus = require("../db/db.config");

const choferSchema = dbBus.chofer
module.exports = choferSchema;
