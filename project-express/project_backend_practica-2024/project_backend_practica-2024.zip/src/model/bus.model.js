const dbBus = require("../db/db.config");

const busSchema = dbBus.bus

module.exports = busSchema;
