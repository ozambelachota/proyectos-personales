const dbBus = require("../db/db.config");

const asientoSchema = dbBus.asiento;
module.exports = asientoSchema;
